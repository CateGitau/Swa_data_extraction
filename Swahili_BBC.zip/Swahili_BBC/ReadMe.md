# BBC Swahili Data
(https://www.bbc.com/swahili/michezo)

Number of Articles: 1554
Number of tokens: 739587
Number of sentences: 33293


Category: Sports/Michezo


