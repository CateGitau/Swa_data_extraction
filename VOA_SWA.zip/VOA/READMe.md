[VOA Swahili data](https://www.voaswahili.com/z/2772)

Total articles: 1111
Date till -> June 29th 2020
